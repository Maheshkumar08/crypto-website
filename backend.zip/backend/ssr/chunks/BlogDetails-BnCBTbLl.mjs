import { c as ssrRenderComponent_1, v as vueExports } from "../entry-server.mjs";
import { i as incrementBlogViews, g as getBlogs, a as getBlog } from "./blogs-BfNdijss.mjs";
import { _ as _sfc_main$1 } from "./ArticlePage-BoKQWFx3.mjs";
import "node:stream";
import "./text-scSNyQat.mjs";
import "./sanitizeArticleHtml-CaIpdonf.mjs";
import "./seoSchemas-CS1dLiVY.mjs";
import "./useReveal-BQH7su09.mjs";
import "./cloudinary-oFvjB332.mjs";
import "./useBookmarks-DsR5dABP.mjs";
import "./AuthorAvatar-CVtMFWmt.mjs";
import "./BlogCard-CVOwHfOf.mjs";
const _sfc_main = {
  __name: "BlogDetails",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent_1(_sfc_main$1, vueExports.mergeProps({
        "get-fn": vueExports.unref(getBlog),
        "list-fn": vueExports.unref(getBlogs),
        "increment-views-fn": vueExports.unref(incrementBlogViews),
        "base-path": "/blog",
        "list-route-name": "blog",
        "json-ld-type": "BlogPosting",
        collection: "blogs"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/BlogDetails.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
