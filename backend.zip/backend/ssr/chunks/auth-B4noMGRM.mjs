import { a9 as defineStore, Z as api, aa as setAccessToken, ab as refreshSession } from "../entry-server.mjs";
const useAuthStore = defineStore("auth", {
  state: () => ({
    user: null,
    ready: false
  }),
  getters: {
    isAuthenticated: (state) => !!state.user
  },
  actions: {
    init() {
      return this.ensureLoaded();
    },
    /** Restores the session from the refresh cookie once per page load. */
    async ensureLoaded() {
      if (this.ready) return this.user;
      try {
        const session = await refreshSession();
        this.user = session.user;
      } catch {
        this.user = null;
      }
      this.ready = true;
      return this.user;
    },
    async login(email, password) {
      const session = await api.post("/auth/login", { email: email.trim(), password });
      setAccessToken(session.accessToken);
      this.user = session.user;
      this.ready = true;
      return session.user;
    },
    async logout() {
      try {
        await api.post("/auth/logout");
      } finally {
        setAccessToken(null);
        this.user = null;
      }
    }
  }
});
export {
  useAuthStore as u
};
