import { Z as api, $ as query, a0 as toDate } from "../entry-server.mjs";
const GUIDE_CATEGORIES = [
  { value: "getting-started", label: "Getting Started" },
  { value: "safety", label: "Safety" },
  { value: "coins", label: "Coins" },
  { value: "exchanges", label: "Exchanges" },
  { value: "taxes", label: "Taxes" },
  { value: "glossary", label: "Glossary" }
];
function normalize(doc) {
  return {
    ...doc,
    order: typeof doc.order === "number" ? doc.order : 0,
    enabled: doc.enabled !== false,
    createdAt: toDate(doc.createdAt),
    updatedAt: toDate(doc.updatedAt)
  };
}
async function listGuideCards({ category, enabledOnly = false } = {}) {
  const cards = (await api.get(`/guide-cards${query({ category, enabledOnly: enabledOnly ? 1 : void 0 })}`)).map(normalize);
  return cards.sort((a, b) => a.order - b.order);
}
async function getGuideCardById(id) {
  try {
    return normalize(await api.get(`/guide-cards/${encodeURIComponent(id)}`));
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }
}
async function updateGuideCard(id, data) {
  await api.put(`/guide-cards/${encodeURIComponent(id)}`, data);
}
async function deleteGuideCard(id) {
  await api.delete(`/guide-cards/${encodeURIComponent(id)}`);
}
async function reorderGuideCards(cards) {
  await api.put("/guide-cards/reorder", { ids: cards.map((card) => card.id) });
}
export {
  GUIDE_CATEGORIES as G,
  deleteGuideCard as d,
  getGuideCardById as g,
  listGuideCards as l,
  reorderGuideCards as r,
  updateGuideCard as u
};
