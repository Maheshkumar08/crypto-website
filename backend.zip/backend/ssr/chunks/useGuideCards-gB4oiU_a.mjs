import { v as vueExports, P as PRERENDER_STATE, a5 as getServerGuideCards, O as getServerPosts } from "../entry-server.mjs";
import "./articles-Csgd8dfv.mjs";
function linkedArticle({ content, faqs, keyTakeaways, ...rest }) {
  return rest;
}
function joinCards(guideCards, articles) {
  const byCardId = new Map(articles.filter((a) => a.guideCardId).map((a) => [a.guideCardId, a]));
  return guideCards.map((card) => {
    const article = byCardId.get(card.cardId);
    return { ...card, article: article ? linkedArticle(article) : null };
  });
}
function useGuideCards(category) {
  const cards = vueExports.ref([]);
  const loading = vueExports.ref(true);
  const error = vueExports.ref("");
  const prerenderState = vueExports.inject(PRERENDER_STATE, null);
  const stateKey = `guide-cards:${category}`;
  {
    vueExports.onServerPrefetch(async () => {
      try {
        const [guideCards, articles] = await Promise.all([getServerGuideCards(category), getServerPosts("articles")]);
        cards.value = joinCards(guideCards, articles);
      } catch (err) {
        console.error("[guide-cards] server render failed:", err);
        error.value = "Could not load guides right now.";
      }
      loading.value = false;
      if (prerenderState && !error.value) prerenderState[stateKey] = cards.value;
    });
  }
  return { cards, loading, error };
}
export {
  useGuideCards as u
};
